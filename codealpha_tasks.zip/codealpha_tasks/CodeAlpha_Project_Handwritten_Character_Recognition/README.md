# CodeAlpha Project - Handwritten Character Recognition

**Internship:** CodeAlpha Machine Learning Internship  
**Task:** 3 - Handwritten Character Recognition

## Objective
Identify handwritten digits using a Convolutional Neural Network (CNN).

## Dataset
MNIST handwritten digit dataset provided through TensorFlow/Keras.

## Model
- Conv2D
- MaxPooling2D
- Flatten
- Dense layers
- Dropout
- Softmax output

## Evaluation
The project reports:
- Test accuracy
- Precision
- Recall
- F1-score
- Confusion matrix

## Run
```bash
pip install -r requirements.txt
python mnist_cnn.py
```

The first run downloads the MNIST dataset automatically.