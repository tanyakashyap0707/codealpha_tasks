# CodeAlpha Project - Credit Scoring Model

**Internship:** CodeAlpha Machine Learning Internship  
**Task:** 1 - Credit Scoring Model

## Objective
Predict an individual's creditworthiness using financial-history features.

## Features
- Income
- Debt
- Payment history
- Credit age
- Number of late payments

## Approach
A Random Forest classification model is trained and evaluated using:
- Precision
- Recall
- F1-score
- ROC-AUC
- Confusion Matrix

## Run
```bash
pip install -r requirements.txt
python credit_scoring.py
```

The script creates `credit_data.csv`, `confusion_matrix.png`, and `roc_curve.png`.

> Educational project. The dataset is synthetic and must not be used for real lending decisions.